This data bundle contains the following elements:

ModPref.csv
EqualPref.csv
NoPref.csv
StrongPref.csv
Collins.csv
Lewis.csv

These are the data files for input into R corresponding to the data in
Table 1 and used in Section 5.

MT.csv

This is the data file for input into R corresponding to the data in
Table 2, and used in Section 5.

commands.txt

This is a script of the R commands required to obtain the results
discussed in Section 5, along with some comments on their use.
